# KappaRWA Portfolio

## Overview
KappaRWA is a stunning portfolio website showcasing real-world asset (RWA) tokenization projects with AI integration themes. Built by Emmanuel Daniels, the site features an animated particle background, glassmorphism effects, and a modern dark theme with blue gradient accents.

## Recent Changes
- **2025-11-11**: Project successfully imported and configured for Replit environment
- **2025-11-11**: EmailJS fully configured and active - contact form sends real emails
- **2025-11-11**: Navbar enhanced with gradient underline indicators for active routes and nested route support
- **2025-11-11**: Project cards redesigned with glassmorphism thumbnails and metric grids
- **2025-11-11**: Hero section updated with gradient mesh visualization
- **2025-11-11**: Complete portfolio implementation with animated background, navigation, hero section, projects showcase, project details, about page, and contact form

## Project Architecture

### Frontend Stack
- **Framework**: React with Wouter for routing
- **Styling**: Tailwind CSS with custom dark theme
- **UI Components**: Shadcn/ui with glassmorphism effects
- **Animations**: Canvas-based particle animation system
- **Fonts**: Inter (Google Fonts)

### Design System
- **Primary Color**: #0b5fff (blue)
- **Accent Color**: #00C2FF (cyan)
- **Background**: Very dark blue (#060814 equivalent)
- **Cards**: Glassmorphism with rgba backgrounds and subtle borders
- **Typography**: Inter font family throughout

### Pages
1. **Home** (`/`) - Hero section with gradient text and feature snapshot cards
2. **Projects** (`/projects`) - Grid showcase of RWA demo projects
3. **Project Detail** (`/projects/:id`) - Individual project information with metrics
4. **About** (`/about`) - Emmanuel Daniels bio and skills
5. **Contact** (`/contact`) - Contact form with validation

### Featured Projects
- **Maple Finance** - Institutional Credit (Ethereum, $350M TVL, AI Score: 89)
- **RealToken** - Real Estate (Gnosis, $142M TVL, AI Score: 84)
- **Ondo-Lite** - Treasuries (Multiple chains, $11.5B TVL, AI Score: 91)
- **AgriLend** - Agriculture (Polygon, $2.3M TVL, AI Score: 72)

### Components
- **AnimatedBackground** - Canvas particle system with network visualization effects
- **Navbar** - Sticky navigation with gradient underline indicators, nested route support, and mobile menu
- **Hero** - Two-column layout with gradient mesh visual, stats bar showing project metrics
- **ProjectCard** - Glassmorphism cards with gradient thumbnail headers and 2x2 metric grids

## User Preferences
- Dark theme with high contrast blue gradients
- Glassmorphism aesthetic for cards and UI elements
- Animated particle background for tech-forward feel
- Clean, minimal design focused on content
- Responsive design for all screen sizes

## Data Model
Projects are stored as static data with the following structure:
- id (string) - Unique identifier
- name (string) - Project name
- desc (string) - Project description
- type (string) - Asset type category
- tvl (string) - Total value locked
- chain (string) - Blockchain network
- score (number) - Quality/rating score

## EmailJS Configuration

The contact form is **fully configured** with EmailJS integration for real email delivery.

**Current Configuration** (stored in Replit Secrets):
- `VITE_EMAILJS_SERVICE_ID` = service_3x08t99
- `VITE_EMAILJS_TEMPLATE_ID` = l-teFbMJKtRddHMQuWZMd
- `VITE_EMAILJS_PUBLIC_KEY` = NvYYnIQ-liAISOn8V

**Template Variables** (configured in EmailJS template):
- `{{from_name}}` - Sender's name
- `{{reply_to}}` - Sender's email
- `{{message}}` - Message content

The contact form will now send real emails when visitors submit the form!

## Deployment

The portfolio is **ready to publish**! To deploy:

1. Click the "Publish" button in Replit
2. Your portfolio will be live at `https://[your-repl-name].replit.app`
3. (Optional) Configure a custom domain in Replit settings

✓ EmailJS is already configured - contact form will work in production!

## Notes
- All project data is static (no database needed)
- Dark theme is the default and only theme
- Fully responsive design works on all screen sizes
- E2E tests verify all navigation and form functionality
