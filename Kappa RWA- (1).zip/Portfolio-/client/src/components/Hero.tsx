import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function Hero() {
  return (
    <section className="relative py-16 md:py-24 lg:py-32">
      <div className="container max-w-7xl mx-auto px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold leading-tight text-foreground">
              Building the bridge between{' '}
              <span className="text-primary">Real-World Assets</span>,{' '}
              <span className="text-accent">AI</span> & Crypto
            </h1>
            <p className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed">
              I'm <strong className="text-foreground">Emmanuel Daniels</strong>, founder of{' '}
              <strong className="text-foreground">KappaRWA</strong> — crafting investor-ready RWA
              marketplaces and AI-backed dashboards.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/projects">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-lg shadow-primary/20"
                  data-testid="button-view-projects"
                >
                  View Projects
                </Button>
              </Link>
              <Link href="/contact">
                <Button
                  size="lg"
                  variant="outline"
                  data-testid="button-contact"
                >
                  Contact
                </Button>
              </Link>
            </div>
          </div>

          <div className="hidden md:flex items-center justify-center relative">
            <div className="relative w-full h-96">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-accent/20 to-primary/10 rounded-2xl blur-3xl"></div>
              <div className="absolute inset-4 bg-gradient-to-tr from-primary/10 via-transparent to-accent/10 rounded-xl border border-primary/20 backdrop-blur-sm"></div>
              <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-primary/30 rounded-full blur-2xl animate-pulse"></div>
              <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-accent/30 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '1s' }}></div>
            </div>
          </div>
        </div>

        <div className="mt-16 md:mt-24 grid grid-cols-3 gap-6 md:gap-8">
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-foreground" data-testid="text-stat-projects">4</div>
            <div className="text-sm text-muted-foreground mt-2">Projects</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-foreground" data-testid="text-stat-tvl">$2.85M</div>
            <div className="text-sm text-muted-foreground mt-2">Total TVL</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-foreground" data-testid="text-stat-chains">4</div>
            <div className="text-sm text-muted-foreground mt-2">Chains</div>
          </div>
        </div>
      </div>
    </section>
  );
}
