# KappaRWA Portfolio Design Guidelines

## Design Approach
**System**: Custom tech-forward design inspired by Linear's precision + Stripe's clarity, optimized for crypto/fintech credibility and investor appeal.

## Core Design Principles
- **Tech Premium**: Sophisticated, data-driven aesthetic that signals technical expertise
- **Trust & Credibility**: Professional polish suitable for institutional audiences
- **Performance Focus**: Clean, efficient UI that prioritizes information hierarchy

---

## Typography

**Font Stack**: Inter (already specified via Google Fonts)

**Hierarchy**:
- H1 (Hero): `text-5xl md:text-6xl lg:text-7xl font-extrabold leading-tight`
- H2 (Section): `text-3xl md:text-4xl font-bold`
- H3 (Card Title): `text-xl font-semibold`
- Body: `text-base leading-relaxed`
- Caption/Meta: `text-sm text-slate-400`

---

## Layout System

**Spacing Units**: Tailwind `4, 6, 8, 12, 16, 24` for consistent rhythm
- Section padding: `py-16 md:py-24 lg:py-32`
- Card padding: `p-6 md:p-8`
- Element gaps: `gap-6 md:gap-8`

**Container**: `max-w-7xl mx-auto px-4 md:px-6`

---

## Component Library

### Hero Section
- Full-width layout with gradient text effects
- Two-column grid on desktop: Content left, visual asset right
- Prominent dual-CTA pattern (primary gradient + outline)
- Stats bar below fold: "X Projects • Y Total TVL • Z Chains"

### Navigation
- Sticky header with backdrop blur: `backdrop-blur-lg bg-slate-950/80`
- Logo: Gradient text "KappaRWA" with brand accent
- Desktop: Horizontal nav with underline indicators for active state
- Mobile: Hamburger menu (slide-in drawer)

### Project Cards
- Glassmorphism treatment: `bg-white/[0.03] border border-white/10`
- Hover state: `hover:bg-white/[0.06] hover:border-white/20 transition-all duration-300`
- Badge system for tags: `bg-blue-500/10 text-blue-400 px-3 py-1 rounded-full text-xs`
- Metrics display: Grid of small stat boxes within card
- Thumbnail area at top (200px height) with gradient overlay if no image

### Data Display
- Metric Cards: Large number + label, subtle gradient backgrounds
- Chain badges: Small colored dots + chain name
- Score indicators: Progress bar or circular gauge (0-100)

### Forms
- Input fields: `bg-white/[0.02] border border-white/10 focus:border-blue-500 px-4 py-3 rounded-lg`
- Textarea: Same treatment, `min-h-40`
- Primary button: Gradient `from-blue-600 to-cyan-500` with `hover:shadow-lg hover:shadow-blue-500/50`
- Secondary button: `border border-slate-700 hover:bg-white/5`

### Background Elements
- Animated particle canvas (already implemented)
- Subtle gradient overlays: `bg-gradient-to-b from-transparent via-blue-950/5 to-transparent`
- Grid pattern overlay option: Faint CSS grid lines for tech aesthetic

---

## Page-Specific Guidelines

### Homepage
- Hero: Headline + subtext + dual CTAs + optional tech graphic/illustration
- Stats section: 3-4 column grid with key metrics
- Featured projects: 3-column grid, top 3-6 projects
- Capabilities section: 2-column feature blocks with icons

### Projects Page
- Filter bar: Horizontal scroll of category chips
- 3-column responsive grid (1 col mobile, 2 tablet, 3 desktop)
- "Load more" or pagination at bottom

### Project Detail
- Hero banner with project name + key stat badges
- 2-column layout: Main content left, sidebar right (chain, TVL, metrics)
- Technical specs: Expandable accordion sections
- Related projects: Horizontal scroll carousel at bottom

### About
- Profile section: Photo + bio in 2-column layout
- Skills grid: 3-4 columns of tech stack icons with labels
- Timeline: Vertical line with milestone markers (if applicable)

### Contact
- Split layout: Form left (60%), contact info + social right (40%)
- Success state: Inline confirmation with checkmark animation

---

## Images

**Hero Section**: Abstract tech illustration or 3D render
- Style: Floating geometric shapes, network nodes, or blockchain visualization
- Treatment: Subtle glow effects, semi-transparent
- Placement: Right side of hero, 50% width on desktop
- Fallback: Blue gradient mesh if no image

**Project Cards**: Placeholder graphics
- Use gradient backgrounds with project initials or simple geometric patterns
- Consistent 16:9 aspect ratio
- Overlay: Subtle gradient fade from bottom

**About Page**: Professional headshot
- Circular crop, 200-300px diameter
- Subtle border with gradient accent

**No large stock photos** - focus on data visualization, icons, and custom graphics that reinforce the tech/crypto theme.

---

## Interactions

**Minimal Animation Strategy**:
- Card hover: Subtle lift (`transform: translateY(-4px)`) + border glow
- Button hover: Slight scale (1.02) + shadow enhancement
- Page transitions: Fade only, no sliding
- Scroll reveals: Fade-in on elements entering viewport (stagger by 100ms)

**No** complex parallax, morphing, or excessive motion - maintain professional restraint.

---

## Accessibility
- Contrast ratios: Minimum 4.5:1 for all text
- Focus indicators: `ring-2 ring-blue-500 ring-offset-2 ring-offset-slate-950`
- Skip to content link
- Semantic HTML throughout
- ARIA labels on interactive elements