import { Link, useLocation } from 'wouter';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

export default function Navbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/projects', label: 'Projects' },
    { path: '/about', label: 'About' },
    { path: '/contact', label: 'Contact' },
  ];

  return (
    <header className="sticky top-0 z-50 backdrop-blur-lg bg-background/80 border-b border-border/50">
      <div className="container max-w-7xl mx-auto py-6 px-4 md:px-6">
        <div className="flex items-center justify-between">
        <Link href="/" data-testid="link-home">
          <div className="text-2xl md:text-3xl font-extrabold cursor-pointer">
            <span className="bg-gradient-to-r from-white to-accent bg-clip-text text-transparent">
              Kappa
            </span>
            <span className="text-primary">RWA</span>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm">
          {navLinks.map((link) => {
            const isActive = 
              location === link.path || 
              (link.path !== '/' && location.startsWith(link.path));
            
            return (
              <Link key={link.path} href={link.path}>
                <span
                  data-testid={`link-${link.label.toLowerCase()}`}
                  className={`cursor-pointer transition-colors relative pb-1 ${
                    isActive
                      ? 'text-foreground font-semibold'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-primary to-accent"></span>
                  )}
                </span>
              </Link>
            );
          })}
        </nav>

        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="button-menu-toggle"
        >
          {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="container max-w-7xl mx-auto px-4 md:px-6">
        <nav className="md:hidden mt-6 flex flex-col gap-4 pb-4">
          {navLinks.map((link) => {
            const isActive = 
              location === link.path || 
              (link.path !== '/' && location.startsWith(link.path));
            
            return (
              <Link key={link.path} href={link.path}>
                <span
                  onClick={() => setMobileMenuOpen(false)}
                  data-testid={`link-mobile-${link.label.toLowerCase()}`}
                  className={`block py-2 cursor-pointer transition-colors ${
                    isActive
                      ? 'text-foreground font-semibold'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {link.label}
                </span>
              </Link>
            );
          })}
        </nav>
        </div>
      )}
    </header>
  );
}
