import { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { contactFormSchema, type ContactForm } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle2, AlertCircle } from 'lucide-react';
import emailjs from '@emailjs/browser';

/**
 * EmailJS Configuration
 * 
 * To enable email sending, add these to your Replit Secrets:
 * - VITE_EMAILJS_SERVICE_ID (from EmailJS dashboard)
 * - VITE_EMAILJS_TEMPLATE_ID (from EmailJS dashboard)  
 * - VITE_EMAILJS_PUBLIC_KEY (from EmailJS account page)
 * 
 * Get them at: https://www.emailjs.com/
 */
const EMAILJS_CONFIG = {
  serviceId: import.meta.env.VITE_EMAILJS_SERVICE_ID,
  templateId: import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
  publicKey: import.meta.env.VITE_EMAILJS_PUBLIC_KEY,
};

const isEmailJSConfigured = !!(
  EMAILJS_CONFIG.serviceId && 
  EMAILJS_CONFIG.templateId && 
  EMAILJS_CONFIG.publicKey
);

export default function Contact() {
  const formRef = useRef<HTMLFormElement>(null);
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();

  const form = useForm<ContactForm>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      from_name: '',
      reply_to: '',
      message: '',
    },
  });

  const onSubmit = async (data: ContactForm) => {
    try {
      if (isEmailJSConfigured && formRef.current) {
        await emailjs.sendForm(
          EMAILJS_CONFIG.serviceId!,
          EMAILJS_CONFIG.templateId!,
          formRef.current,
          EMAILJS_CONFIG.publicKey!
        );
        
        setSubmitted(true);
        form.reset();
        
        toast({
          title: 'Message sent!',
          description: "Thank you for reaching out. I'll get back to you soon.",
        });
      } else {
        console.log('EmailJS not configured. Form data:', data);
        
        setSubmitted(true);
        form.reset();
        
        toast({
          title: 'Form submitted (Demo mode)',
          description: 'EmailJS is not configured. Configure secrets to enable email delivery.',
        });
      }

      setTimeout(() => setSubmitted(false), 5000);
    } catch (error) {
      console.error('EmailJS error:', error);
      toast({
        title: 'Failed to send message',
        description: 'Please try again later.',
        variant: 'destructive',
      });
    }
  };

  return (
    <section className="container max-w-7xl mx-auto px-4 md:px-6 py-16 md:py-24 lg:py-32">
      <h1 className="text-3xl md:text-4xl font-bold text-foreground">Contact</h1>
      <p className="mt-3 text-lg text-muted-foreground">
        Get in touch to discuss RWA projects, collaborations, or opportunities.
      </p>

      <Card className="mt-8 max-w-2xl bg-card/50 backdrop-blur-sm border-card-border">
        <CardHeader>
          <h2 className="text-xl font-semibold text-foreground">Send a Message</h2>
          {!isEmailJSConfigured && (
            <div className="flex items-start gap-2 mt-3 text-sm text-muted-foreground bg-accent/10 border border-accent/20 rounded-md p-3">
              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <div>
                <strong>Demo Mode:</strong> EmailJS is not configured. Messages will not be delivered. 
                Add VITE_EMAILJS_* secrets to enable email delivery.
              </div>
            </div>
          )}
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form ref={formRef} onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="from_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Your name"
                        {...field}
                        data-testid="input-name"
                        className="bg-background/50"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="reply_to"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="your.email@example.com"
                        {...field}
                        data-testid="input-email"
                        className="bg-background/50"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Message</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Tell me about your project or inquiry..."
                        className="min-h-40 bg-background/50"
                        {...field}
                        data-testid="input-message"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                size="lg"
                disabled={form.formState.isSubmitting}
                className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity"
                data-testid="button-submit"
              >
                {form.formState.isSubmitting ? 'Sending...' : 'Send Message'}
              </Button>

              {submitted && (
                <div
                  className="flex items-center gap-2 text-green-500 text-sm"
                  data-testid="text-success"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Message sent successfully!</span>
                </div>
              )}
            </form>
          </Form>
        </CardContent>
      </Card>
    </section>
  );
}
