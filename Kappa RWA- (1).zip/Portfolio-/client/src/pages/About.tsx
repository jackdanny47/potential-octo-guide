import { Card, CardContent, CardHeader } from '@/components/ui/card';

export default function About() {
  return (
    <section className="container max-w-7xl mx-auto px-4 md:px-6 py-16 md:py-24 lg:py-32">
      <h1 className="text-3xl md:text-4xl font-bold text-foreground">
        About — Emmanuel Daniels
      </h1>
      <p className="mt-6 text-lg text-muted-foreground max-w-4xl leading-relaxed">
        Founder of <strong className="text-foreground">KappaRWA</strong>, Emmanuel Daniels builds
        systems that merge tokenized real-world assets with AI and crypto infrastructure using
        Next.js, Tailwind, and automation-first design.
      </p>

      <div className="mt-12 grid md:grid-cols-2 gap-8">
        <Card className="bg-card/50 backdrop-blur-sm border-card-border hover-elevate transition-all duration-300">
          <CardHeader>
            <h4 className="text-xl font-semibold text-foreground">Core Skills</h4>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-muted-foreground leading-relaxed">
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Next.js • Tailwind • Framer Motion</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Supabase • Serverless • AI APIs</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Tokenization UX & Web3 UI</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm border-card-border hover-elevate transition-all duration-300">
          <CardHeader>
            <h4 className="text-xl font-semibold text-foreground">Focus</h4>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-relaxed">
              Fast, investor-ready RWA marketplaces and dashboards with lean deployment strategies.
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
