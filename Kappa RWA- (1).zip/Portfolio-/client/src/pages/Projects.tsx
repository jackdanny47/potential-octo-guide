import ProjectCard from '@/components/ProjectCard';
import { type Project } from '@shared/schema';

const projects: Project[] = [
  {
    id: 'maple-finance',
    name: 'Maple Finance',
    desc: 'Lending protocol demo for real-world credit.',
    type: 'Debt Protocol',
    tvl: '$1.2M',
    chain: 'Ethereum',
    score: 86,
  },
  {
    id: 'real-token',
    name: 'RealToken',
    desc: 'Fractionalized real estate token demo.',
    type: 'Real Estate',
    tvl: '$460k',
    chain: 'Polygon',
    score: 78,
  },
  {
    id: 'ondo-proto',
    name: 'Ondo-Lite',
    desc: 'Securitized asset simulation.',
    type: 'Securitized Assets',
    tvl: '$980k',
    chain: 'Arbitrum',
    score: 81,
  },
  {
    id: 'agrilend',
    name: 'AgriLend',
    desc: 'Commodity-backed lending demo.',
    type: 'Commodities',
    tvl: '$210k',
    chain: 'BSC',
    score: 72,
  },
];

export default function Projects() {
  return (
    <section className="container max-w-7xl mx-auto px-4 md:px-6 py-16 md:py-24 lg:py-32">
      <h1 className="text-3xl md:text-4xl font-bold text-foreground">
        Projects
      </h1>
      <p className="mt-3 text-muted-foreground text-lg">
        Curated demos and RWA prototypes.
      </p>
      
      <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        {projects.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </section>
  );
}
