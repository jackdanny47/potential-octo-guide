import { Link, useParams, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { type Project } from '@shared/schema';

const projectData: Record<string, Project> = {
  'maple-finance': {
    id: 'maple-finance',
    name: 'Maple Finance',
    desc: 'Demo lending protocol for real-world credit.',
    type: 'Debt',
    chain: 'Ethereum',
    tvl: '$1.2M',
    score: 86,
  },
  'real-token': {
    id: 'real-token',
    name: 'RealToken',
    desc: 'Fractional real estate tokens.',
    type: 'Real Estate',
    chain: 'Polygon',
    tvl: '$460k',
    score: 78,
  },
  'ondo-proto': {
    id: 'ondo-proto',
    name: 'Ondo-Lite',
    desc: 'Securitized asset platform simulation.',
    type: 'Assets',
    chain: 'Arbitrum',
    tvl: '$980k',
    score: 81,
  },
  'agrilend': {
    id: 'agrilend',
    name: 'AgriLend',
    desc: 'Commodity-backed lending demo.',
    type: 'Commodities',
    chain: 'BSC',
    tvl: '$210k',
    score: 72,
  },
};

export default function ProjectDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const project = params.id ? projectData[params.id] : null;

  if (!project) {
    return (
      <section className="container max-w-7xl mx-auto px-4 md:px-6 py-16 md:py-24 lg:py-32">
        <h1 className="text-3xl font-bold text-foreground">Project Not Found</h1>
        <p className="mt-3 text-muted-foreground">
          The project you're looking for doesn't exist.
        </p>
        <Link href="/projects">
          <Button className="mt-6" variant="outline" data-testid="button-back">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Projects
          </Button>
        </Link>
      </section>
    );
  }

  return (
    <section className="container max-w-7xl mx-auto px-4 md:px-6 py-16 md:py-24 lg:py-32">
      <Link href="/projects">
        <Button variant="ghost" className="mb-6 -ml-2" data-testid="button-back">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Projects
        </Button>
      </Link>

      <h1 className="text-3xl md:text-4xl font-bold text-foreground" data-testid="text-project-name">
        {project.name}
      </h1>
      <p className="mt-4 text-lg text-muted-foreground max-w-3xl leading-relaxed">
        {project.desc}
      </p>

      <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
        <Card className="bg-card/50 backdrop-blur-sm border-card-border">
          <CardHeader className="pb-2">
            <div className="text-sm text-muted-foreground">Asset Type</div>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-semibold text-foreground" data-testid="text-asset-type">
              {project.type}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm border-card-border">
          <CardHeader className="pb-2">
            <div className="text-sm text-muted-foreground">Chain</div>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-semibold text-foreground" data-testid="text-chain">
              {project.chain}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm border-card-border">
          <CardHeader className="pb-2">
            <div className="text-sm text-muted-foreground">TVL</div>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-semibold text-foreground" data-testid="text-tvl">
              {project.tvl}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm border-card-border">
          <CardHeader className="pb-2">
            <div className="text-sm text-muted-foreground">Score</div>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-semibold text-foreground" data-testid="text-score">
              {project.score}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
