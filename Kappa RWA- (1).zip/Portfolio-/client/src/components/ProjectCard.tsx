import { Link } from 'wouter';
import { type Project } from '@shared/schema';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface ProjectCardProps {
  project: Project;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  return (
    <Link href={`/projects/${project.id}`}>
      <Card
        className="h-full overflow-hidden cursor-pointer transition-all duration-300 bg-card/50 backdrop-blur-sm border-card-border hover:bg-card/70 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/10"
        data-testid={`card-project-${project.id}`}
      >
        <div className="h-48 bg-gradient-to-br from-primary/20 via-accent/10 to-primary/5 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-card/90 via-card/50 to-transparent"></div>
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="text-xl font-semibold text-foreground">
              {project.name}
            </h3>
          </div>
        </div>
        
        <CardContent className="space-y-4 pt-4">
          <p className="text-sm text-muted-foreground line-clamp-2">
            {project.desc}
          </p>
          
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <div className="text-xs text-muted-foreground">Type</div>
              <div className="text-sm font-medium text-foreground mt-1">{project.type}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Chain</div>
              <div className="text-sm font-medium text-foreground mt-1">{project.chain}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">TVL</div>
              <div className="text-sm font-semibold text-foreground mt-1" data-testid={`text-tvl-${project.id}`}>
                {project.tvl}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Score</div>
              <div className="text-sm font-semibold text-foreground mt-1">{project.score}</div>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="pt-0">
          <span className="text-accent text-sm font-semibold hover:underline">
            View Details →
          </span>
        </CardFooter>
      </Card>
    </Link>
  );
}
