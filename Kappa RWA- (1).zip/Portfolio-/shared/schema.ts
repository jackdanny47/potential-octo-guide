import { z } from "zod";

export const projectSchema = z.object({
  id: z.string(),
  name: z.string(),
  desc: z.string(),
  type: z.string(),
  tvl: z.string(),
  chain: z.string(),
  score: z.number(),
});

export type Project = z.infer<typeof projectSchema>;

export const contactFormSchema = z.object({
  from_name: z.string().min(1, "Name is required"),
  reply_to: z.string().email("Valid email is required"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

export type ContactForm = z.infer<typeof contactFormSchema>;

export const userSchema = z.object({
  id: z.string(),
  username: z.string(),
  password: z.string(),
});

export type User = z.infer<typeof userSchema>;
export type InsertUser = Omit<User, "id">;
