import Hero from '@/components/Hero';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

export default function Home() {
  const features = [
    {
      category: 'Marketplace',
      title: 'RWA Directory & Dashboard',
    },
    {
      category: 'AI Integrations',
      title: 'Auto Analysis & Insights',
    },
    {
      category: 'Token UX',
      title: 'Investor-ready Interfaces',
    },
  ];

  return (
    <>
      <Hero />
      
      <section className="container max-w-7xl mx-auto mt-16 md:mt-24 px-4 md:px-6 pb-16 md:pb-24">
        <h2 className="text-3xl md:text-4xl font-bold text-foreground">
          Snapshot
        </h2>
        <p className="mt-3 text-muted-foreground max-w-3xl text-lg leading-relaxed">
          KappaRWA builds next-gen systems linking real-world assets, AI, and crypto ecosystems.
        </p>
        
        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="bg-card/50 backdrop-blur-sm border-card-border hover-elevate transition-all duration-300"
              data-testid={`card-feature-${index}`}
            >
              <CardHeader className="pb-3">
                <div className="text-sm text-muted-foreground font-medium">
                  {feature.category}
                </div>
              </CardHeader>
              <CardContent>
                <div className="font-semibold text-lg text-foreground">
                  {feature.title}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </>
  );
}
